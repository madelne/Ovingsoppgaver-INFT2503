#include <gtkmm.h>

class Window : public Gtk::Window {
public:
  Gtk::Box box;
  Gtk::Label first_name_label;
  Gtk::Entry first_name_entry;
  Gtk::Label last_name_label;
  Gtk::Entry last_name_entry;
  Gtk::Button button;
  Gtk::Label label;

  Window() : box(Gtk::Orientation::ORIENTATION_VERTICAL) {
    set_title("Øving 4");
    button.set_label("Combine names");
    first_name_label.set_text("First name");
    last_name_label.set_text("Last name");
    button.set_sensitive(false);

    box.pack_start(first_name_label); // Add the widget first name label to box
    box.pack_start(first_name_entry); // Add the widget first name entry to box
    box.pack_start(last_name_label);  // Add the widget last name label to box
    box.pack_start(last_name_entry);  // Add the widget last name entry to box
    box.pack_start(button);           // Add the widget button to box
    box.pack_start(label);            // Add the widget button label to box

    add(box);   // Add vbox to window
    show_all(); // Show all widgets

    first_name_entry.signal_changed().connect([this]() {
      if (first_name_entry.get_text_length() == 0) {
        button.set_sensitive(false);
      }
      if (first_name_entry.get_text_length() > 0 && last_name_entry.get_text_length() > 0) {
        button.set_sensitive();
      }
    });

    last_name_entry.signal_changed().connect([this]() {
      if (last_name_entry.get_text_length() == 0) {
        button.set_sensitive(false);
      }
      if (first_name_entry.get_text_length() > 0 && last_name_entry.get_text_length() > 0) {
        button.set_sensitive();
      }
    });

    button.signal_clicked().connect([this]() {
      label.set_text("Name combined:" + first_name_entry.get_text() + " " + last_name_entry.get_text());
    });
  }
};

int main() {
  auto app = Gtk::Application::create();
  Window window;
  return app->run(window);
}
